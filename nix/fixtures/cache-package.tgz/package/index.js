module.exports = (value) => `verified:${value}`
