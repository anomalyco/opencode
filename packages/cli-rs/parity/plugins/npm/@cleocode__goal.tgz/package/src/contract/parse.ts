// Parses and validates goal.yaml. Every rule here is one the write-goal skill
// relies on to tell a loop-verifiable goal from a wish.
import { createHash } from "node:crypto"
import { parse as parseYamlPortable } from "yaml"
import { type AdrDecision, adrIssues, loadAdrDecisions } from "./adr-guard"
import {
  AMEND_CLASSES,
  AUTONOMY_LEVEL_POLICY,
  AUTONOMY_LEVELS,
  CHECK_KINDS,
  CLEO_GATES,
  type AmendClass,
  type AutonomyLevel,
  type CleoGate,
  type CleoTaskLink,
  type GoalAcRef,
  gateForCheck,
  HOST_KINDS,
  PRIORITIES,
  SCHEMA,
  type Assumption,
  type Autonomy,
  type Budget,
  type Check,
  type Contract,
  type Criterion,
  type Issue,
  type Priority,
  type Step,
  type VerificationMode,
  type Workstream,
} from "./types"

export type ParseResult = { contract?: Contract; issues: Issue[]; lock: string }

export type ParseOptions = {
  slug?: string
  tolerateUnknownBudgetKeys?: boolean
  /**
   * T180 — the project root holding the ADR projection
   * (`docs/adr/decisions.json`). Absent ⇒ the current working directory, which
   * is the project being validated for the CLI and the tick. A root with no
   * projection behaves exactly as before (one stat, no warning).
   */
  projectRoot?: string
  /** T180 — decisions to check instead of the on-disk projection (tests, or a caller that already loaded them). */
  decisions?: readonly AdrDecision[]
}

const VAGUE = [
  "fast",
  "faster",
  "quick",
  "quickly",
  "robust",
  "clean",
  "cleaner",
  "better",
  "properly",
  "proper",
  "nice",
  "good",
  "efficient",
  "scalable",
  "intuitive",
  "user-friendly",
  "seamless",
  "seamlessly",
  "optimal",
  "optimized",
  "improved",
  "reasonable",
  "appropriate",
  "correctly",
  "works",
]
const ACTIVITY = /^(keep|continue|improve|investigate|explore|work on|look into|try to|help|refactor as needed|clean up)\b/i
/**
 * v0.5.1 - the three CLEO `satisfies:` AC-reference forms a `proves:` entry may
 * take: `T123#AC2`, `T123#<uuid>` and `T123#AC2@<14-digit pin>`.
 */
export const AC_REF = /^T\d+#(?:AC\d{1,4}|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})(?:@\d{14})?$/

export const lockOf = (text: string) => createHash("sha256").update(text).digest("hex")

const isRecord = (v: unknown): v is Record<string, unknown> => typeof v === "object" && v !== null && !Array.isArray(v)
const str = (v: unknown) => (typeof v === "string" ? v.trim() : typeof v === "number" ? String(v) : "")
const strings = (v: unknown): string[] => (Array.isArray(v) ? v.map(str).filter(Boolean) : typeof v === "string" && v.trim() ? [v.trim()] : [])

/** "90m", "3h", "1h30m", "45s", "2d" → ms. A bare number means minutes. */
export function parseDuration(value: unknown): number | undefined {
  if (typeof value === "number") return value > 0 ? value * 60_000 : undefined
  const text = str(value).toLowerCase().replace(/\s+/g, "")
  if (!text) return undefined
  const units: Record<string, number> = { d: 86_400_000, h: 3_600_000, m: 60_000, s: 1000 }
  let total = 0
  let matched = ""
  for (const part of text.matchAll(/(\d+(?:\.\d+)?)([dhms])/g)) {
    total += Number(part[1]) * units[part[2]!]!
    matched += part[0]
  }
  return matched === text && total > 0 ? Math.round(total) : undefined
}

/** "3M", "400k", "1.5m", 250000 → tokens. */
export function parseCount(value: unknown): number | undefined {
  if (typeof value === "number") return value > 0 ? Math.round(value) : undefined
  const match = /^(\d+(?:\.\d+)?)\s*([kmb])?$/i.exec(str(value))
  if (!match) return undefined
  const scale = { k: 1e3, m: 1e6, b: 1e9 }[(match[2] ?? "").toLowerCase() as "k" | "m" | "b"] ?? 1
  const n = Math.round(Number(match[1]) * scale)
  return n > 0 ? n : undefined
}

function vagueWords(text: string): string[] {
  if (/\d/.test(text)) return []
  const lower = ` ${text.toLowerCase()} `
  return VAGUE.filter((word) => new RegExp(`[^a-z-]${word.replace("-", "\\-")}[^a-z-]`).test(lower))
}

function parseCheck(raw: unknown, path: string, issues: Issue[]): Check | undefined {
  if (!isRecord(raw)) {
    issues.push({ level: "error", path, message: "check is required: say how this criterion is proven (a command, a file test, a search, or a verifier question)" })
    return undefined
  }
  const kind = str(raw.kind)
  if (!(CHECK_KINDS as readonly string[]).includes(kind)) {
    issues.push({ level: "error", path: `${path}.kind`, message: `unknown check kind "${kind}"; use one of ${CHECK_KINDS.join(", ")}` })
    return undefined
  }
  const need = (field: string, value: string) => {
    if (!value) issues.push({ level: "error", path: `${path}.${field}`, message: `${kind} check needs ${field}` })
    return value
  }
  switch (kind) {
    case "command": {
      const expect = isRecord(raw.expect) ? raw.expect : {}
      // v0.8.0 D6: an unimplemented expectation key is an ERROR, never silently
      // dropped. `stderr_contains` used to collapse a criterion to bare
      // `exit: 0`, which passes while proving nothing.
      const supported = ["exit", "stdout_contains", "stdout_regex"] as const
      for (const key of Object.keys(expect))
        if (!(supported as readonly string[]).includes(key))
          issues.push({ level: "error", path: `${path}.expect.${key}`, message: `unknown expectation "${key}"; supported: ${supported.join(", ")}` })
      const out: Check = {
        kind,
        run: need("run", str(raw.run)),
        expect: {
          ...(expect.exit !== undefined ? { exit: Number(expect.exit) } : {}),
          ...(str(expect.stdout_contains) ? { stdout_contains: str(expect.stdout_contains) } : {}),
          ...(str(expect.stdout_regex) ? { stdout_regex: str(expect.stdout_regex) } : {}),
        },
        ...(raw.timeout !== undefined ? { timeout: Number(raw.timeout) } : {}),
        ...(raw.runs !== undefined ? { runs: Math.max(1, Math.min(10, Number(raw.runs) || 1)) } : {}),
        ...(raw.live === true ? { live: true } : {}),
      }
      // T021: a newline in a command check is usually a YAML folded-scalar
      // accident (>- keeps literal newlines before more-indented lines), which
      // made run 0ffe5ac6e001 C3 unrunnable — the host shell executed the
      // skill directory as a command. Intentional multi-line shell is legal,
      // so warn, and always rehearse the exact stored command before claiming.
      if (typeof out.run === "string" && out.run.includes("\n"))
        issues.push({ level: "warning", path: `${path}.run`, message: "command check spans lines: YAML folded scalars (>-) keep literal newlines before more-indented lines, and the host shell will execute each line separately — keep the command on one line unless the newlines are intentional, and rehearse the stored command before claiming" })
      if (out.expect && out.expect.exit === undefined && !out.expect.stdout_contains && !out.expect.stdout_regex) out.expect.exit = 0
      if (out.expect?.stdout_regex) {
        try {
          new RegExp(out.expect.stdout_regex)
        } catch {
          issues.push({ level: "error", path: `${path}.expect.stdout_regex`, message: "not a valid regular expression" })
        }
      }
      if (out.timeout !== undefined && !(out.timeout > 0)) issues.push({ level: "error", path: `${path}.timeout`, message: "timeout must be a positive number of seconds" })
      return out
    }
    case "file":
      return { kind, path: need("path", str(raw.path)), exists: raw.exists !== false }
    case "contains": {
      const text = str(raw.text)
      const regex = str(raw.regex)
      if (!text && !regex) issues.push({ level: "error", path, message: "contains check needs text or regex" })
      return { kind, path: need("path", str(raw.path)), ...(text ? { text } : {}), ...(regex ? { regex } : {}) }
    }
    case "absent":
      return { kind, pattern: need("pattern", str(raw.pattern)), ...(strings(raw.paths).length ? { paths: strings(raw.paths) } : {}) }
    case "diff": {
      const paths = strings(raw.paths)
      if (!paths.length) issues.push({ level: "error", path: `${path}.paths`, message: "diff check needs at least one path" })
      return { kind, paths }
    }
    default:
      return { kind: kind as "verifier" | "human", ask: need("ask", str(raw.ask)) }
  }
}

function parseCriteria(raw: unknown, path: string, prefix: "C" | "I", issues: Issue[]): Criterion[] {
  if (!Array.isArray(raw)) return []
  return raw.flatMap((item, index) => {
    const at = `${path}[${index}]`
    if (!isRecord(item)) {
      issues.push({ level: "error", path: at, message: "must be a mapping with id, statement and check" })
      return []
    }
    const id = str(item.id)
    if (!new RegExp(`^${prefix}\\d+$`).test(id)) issues.push({ level: "error", path: `${at}.id`, message: `id must look like ${prefix}1, ${prefix}2, …` })
    const statement = str(item.statement)
    if (!statement) issues.push({ level: "error", path: `${at}.statement`, message: "statement is required" })
    const vague = vagueWords(statement)
    if (vague.length) issues.push({ level: "warning", path: `${at}.statement`, message: `vague without a number: ${vague.join(", ")} — state the threshold that proves it` })
    const check = parseCheck(item.check, `${at}.check`, issues)
    if (prefix === "I" && check && !(HOST_KINDS as readonly string[]).includes(check.kind))
      issues.push({ level: "error", path: `${at}.check.kind`, message: "invariants must be host-checkable (command, file, contains, absent or diff)" })
    if (!check) return []
    // v0.5.1 - the precise per-criterion CLEO binding: any of the three
    // satisfies forms (bare AC, uuid, or pinned AC).
    const provesRaw = strings(item.proves)
    for (const ref of provesRaw) if (!AC_REF.test(ref)) issues.push({ level: "error", path: `${at}.proves`, message: `AC reference must be one of T123#AC2, T123#<uuid> or T123#AC2@<14-digit pin> (got "${ref}")` })
    const proves = provesRaw.filter((ref) => AC_REF.test(ref))
    return [{ id, statement, essential: prefix === "I" ? true : item.essential !== false, check, ...(proves.length ? { proves: proves as GoalAcRef[] } : {}) }]
  })
}

type YamlParse = (text: string) => unknown
/** Bun's built-in parser inside OpenCode (unchanged behaviour); the portable `yaml` package on plain Node (the npm bin). */
const bunYaml = (globalThis as { Bun?: { YAML?: { parse: YamlParse } } }).Bun?.YAML
const parseYaml: YamlParse = (text) => (bunYaml ? bunYaml.parse(text) : parseYamlPortable(text))

export function parseContract(text: string, options: ParseOptions = {}): ParseResult {
  const issues: Issue[] = []
  const lock = lockOf(text)
  let raw: unknown
  try {
    raw = parseYaml(text)
  } catch (error) {
    issues.push({ level: "error", path: "", message: `not valid YAML: ${error instanceof Error ? error.message : String(error)}${yamlHint(text)}` })
    return { issues, lock }
  }
  if (!isRecord(raw)) {
    issues.push({ level: "error", path: "", message: "goal.yaml must be a mapping" })
    return { issues, lock }
  }

  const err = (path: string, message: string) => issues.push({ level: "error", path, message })
  const warn = (path: string, message: string) => issues.push({ level: "warning", path, message })

  if (raw.schema !== SCHEMA) err("schema", `schema must be "${SCHEMA}"`)
  const id = str(raw.id)
  if (!/^[a-z0-9][a-z0-9-]{0,63}$/.test(id)) err("id", "id must be a kebab-case slug (a-z, 0-9, hyphens)")
  else if (options.slug && id !== options.slug) err("id", `id "${id}" must match its directory name "${options.slug}"`)
  const title = str(raw.title)
  if (!title) err("title", "title is required")
  else if (title.length > 80) warn("title", "keep the title under 80 characters; it is shown in the sidebar")

  const intent = isRecord(raw.intent) ? str(raw.intent.verbatim) : str(raw.intent)
  if (!intent) err("intent.verbatim", "record the owner's own words verbatim; they stay the authoritative source")

  const outcome = str(raw.outcome)
  if (!outcome) err("outcome", "outcome is required: one end state that will be true when the goal is done")
  else {
    if (ACTIVITY.test(outcome)) warn("outcome", "reads as an activity; state the end state that becomes true instead")
    const vague = vagueWords(outcome)
    if (vague.length) warn("outcome", `vague without a number: ${vague.join(", ")}`)
  }

  const nonGoals = strings(raw.non_goals)
  if (!nonGoals.length) err("non_goals", "list at least one non-goal so the loop does not fill the vacuum")

  const criteria = parseCriteria(raw.criteria, "criteria", "C", issues)
  if (!Array.isArray(raw.criteria) || !raw.criteria.length) err("criteria", "at least one criterion is required")
  else if (!criteria.some((c) => c.essential)) err("criteria", "at least one criterion must be essential")
  else if (!criteria.some((c) => c.essential && (HOST_KINDS as readonly string[]).includes(c.check.kind)))
    warn("criteria", "no essential criterion is host-checkable; completion will rest on the verifier and the owner")
  const invariants = parseCriteria(raw.invariants, "invariants", "I", issues)

  const ids = new Set<string>()
  for (const item of [...criteria, ...invariants]) {
    if (ids.has(item.id)) err(item.id, `duplicate id ${item.id}`)
    ids.add(item.id)
  }

  const assumptions: Assumption[] = (Array.isArray(raw.assumptions) ? raw.assumptions : []).flatMap((item: unknown, index: number) => {
    if (!isRecord(item)) return []
    const aid = str(item.id) || `A${index + 1}`
    if (!/^A\d+$/.test(aid)) err(`assumptions[${index}].id`, "id must look like A1, A2, …")
    const status = str(item.status) || "assumed"
    if (!["assumed", "confirmed", "vetoed"].includes(status)) err(`assumptions[${index}].status`, "status must be assumed, confirmed or vetoed")
    return [{ id: aid, text: str(item.text), ...(str(item.rationale) ? { rationale: str(item.rationale) } : {}), ...(typeof item.reversible === "boolean" ? { reversible: item.reversible } : {}), status: status as Assumption["status"] }]
  })

  const plan: Step[] = (Array.isArray(raw.plan) ? raw.plan : []).flatMap((item: unknown, index: number) => {
    if (!isRecord(item)) return []
    const sid = str(item.id)
    if (!/^S\d+$/.test(sid)) err(`plan[${index}].id`, "id must look like S1, S2, …")
    return [{ id: sid, title: str(item.title), proves: strings(item.proves), depends_on: strings(item.depends_on) }]
  })
  const stepIds = new Set(plan.map((s) => s.id))
  for (const step of plan) {
    for (const ref of step.proves) if (!criteria.some((c) => c.id === ref)) err(`plan.${step.id}.proves`, `unknown criterion ${ref}`)
    for (const ref of step.depends_on) if (!stepIds.has(ref)) err(`plan.${step.id}.depends_on`, `unknown step ${ref}`)
    if (!step.title) err(`plan.${step.id}.title`, "step title is required")
  }
  if (hasCycle(plan)) err("plan", "step dependencies form a cycle")

  // D9: the budget block had the same fail-open shape as D6 — an unknown key
  // such as `max_turns` was silently dropped, leaving no budget at all and a
  // mysterious 200-turn backstop. Every key is now either recognised or named
  // in an error.
  const BUDGET_KEYS = ["turns", "wall", "tokens", "cost_usd"] as const
  if (raw.budget !== undefined && !isRecord(raw.budget)) err("budget", `budget must be a mapping with ${BUDGET_KEYS.join(", ")}`)
  const budgetRaw = isRecord(raw.budget) ? raw.budget : {}
  for (const key of Object.keys(budgetRaw)) {
    if ((BUDGET_KEYS as readonly string[]).includes(key)) continue
    // The default is a hard error (D9: a typo must not silently remove the
    // budget). The repair path opts in to tolerating metadata keys so a
    // contract locked under an older, laxer validator can still be read and
    // amended forward instead of bricking its run.
    if (options.tolerateUnknownBudgetKeys) continue
    err(`budget.${key}`, `unknown key; allowed: ${BUDGET_KEYS.join(", ")}`)
  }
  const budget: Budget = {}
  if (budgetRaw.turns !== undefined) {
    const turns = Number(budgetRaw.turns)
    if (Number.isInteger(turns) && turns > 0) budget.turns = turns
    else err("budget.turns", "turns must be a positive integer")
  }
  if (budgetRaw.wall !== undefined) {
    const wallMs = parseDuration(budgetRaw.wall)
    if (wallMs) budget.wallMs = wallMs
    else err("budget.wall", 'wall must be a duration such as "90m" or "3h"')
  }
  if (budgetRaw.tokens !== undefined) {
    const tokens = parseCount(budgetRaw.tokens)
    if (tokens) budget.tokens = tokens
    else err("budget.tokens", 'tokens must be a count such as 400k or "3M"')
  }
  if (budgetRaw.cost_usd !== undefined) {
    const cost = Number(budgetRaw.cost_usd)
    if (cost > 0) budget.cost_usd = cost
    else err("budget.cost_usd", "cost_usd must be a positive number")
  }

  const autonomyRaw = isRecord(raw.autonomy) ? raw.autonomy : {}
  const pick = <T extends string>(path: string, value: unknown, allowed: readonly T[], fallback: T): T => {
    const v = str(value)
    if (!v) return fallback
    if ((allowed as readonly string[]).includes(v)) return v as T
    err(path, `must be one of ${allowed.join(", ")}`)
    return fallback
  }
  // T170: the owner-set ceiling. An explicit flag may narrow it, never widen
  // it; an absent level keeps the legacy per-flag behaviour byte-for-byte.
  let level: AutonomyLevel | undefined
  const levelRaw = str(autonomyRaw.level)
  if (levelRaw) {
    if ((AUTONOMY_LEVELS as readonly string[]).includes(levelRaw)) level = levelRaw as AutonomyLevel
    else err("autonomy.level", `must be one of ${AUTONOMY_LEVELS.join(", ")}`)
  }
  const explicitStall = str(autonomyRaw.on_stall)
    ? pick("autonomy.on_stall", autonomyRaw.on_stall, ["pause", "continue"] as const, "pause")
    : undefined
  let explicitAmend: AmendClass[] | undefined
  if (autonomyRaw.amend !== undefined) {
    explicitAmend = []
    if (!Array.isArray(autonomyRaw.amend)) err("autonomy.amend", `amend must be a list of ${AMEND_CLASSES.join(", ")}`)
    else for (const value of autonomyRaw.amend) {
      const v = str(value)
      if (v && (AMEND_CLASSES as readonly string[]).includes(v)) { if (!explicitAmend.includes(v as AmendClass)) explicitAmend.push(v as AmendClass) }
      else err("autonomy.amend", `unknown change class "${String(value)}"; allowed: ${AMEND_CLASSES.join(", ")}`)
    }
  }
  const ceiling = level ? AUTONOMY_LEVEL_POLICY[level] : undefined
  // Narrowing is allowed and named; widening is not possible through a level.
  for (const c of explicitAmend ?? []) if (ceiling && !ceiling.amend.includes(c)) warn("autonomy.amend", `"${c}" is outside autonomy.level ${level}; it is not granted`)
  if (ceiling && explicitStall === "continue" && ceiling.on_stall === "pause") warn("autonomy.on_stall", `autonomy.level ${level} keeps the stall pause; "continue" is not granted`)
  const amend: AmendClass[] = ceiling
    ? explicitAmend === undefined ? [...ceiling.amend] : explicitAmend.filter((c) => ceiling.amend.includes(c))
    : explicitAmend ?? []
  const onStall: "pause" | "continue" = ceiling
    ? ceiling.on_stall === "continue" && explicitStall !== "pause" ? "continue" : "pause"
    : explicitStall ?? "pause"
  const autonomy: Autonomy = {
    questions: pick("autonomy.questions", autonomyRaw.questions, ["defer", "allow"] as const, "defer"),
    on_user_message: pick("autonomy.on_user_message", autonomyRaw.on_user_message, ["steer", "pause"] as const, "steer"),
    on_interrupt: pick("autonomy.on_interrupt", autonomyRaw.on_interrupt, ["pause", "resume-on-message"] as const, "pause"),
    ...(level ? { level } : {}),
    amend,
    on_stall: onStall,
    ...(autonomyRaw.visit_new_projects === true ? { visit_new_projects: true } : {}),
    ...(autonomyRaw.continue_past_budget === true ? { continue_past_budget: true } : {}),
  }
  const verificationRaw = isRecord(raw.verification) ? raw.verification : {}
  const mode = pick<VerificationMode>("verification.mode", verificationRaw.mode, ["host", "host+verifier", "strict"] as const, "host+verifier")
  const maxRejections = verificationRaw.max_rejections === undefined ? 3 : Number(verificationRaw.max_rejections)
  if (!(Number.isInteger(maxRejections) && maxRejections >= 1 && maxRejections <= 10)) err("verification.max_rejections", "max_rejections must be an integer from 1 to 10")
  const verifierRead = strings(verificationRaw.read)
  if (verificationRaw.read !== undefined && !Array.isArray(verificationRaw.read)) err("verification.read", "read must be a list of folders the verifier may read")
  for (const path of verifierRead) if (/[*?[\]{}]/.test(path)) err("verification.read", `"${path}" must be a plain folder or file path, not a glob`)
  // T107: the contract may name the verifier child's model and effort. The
  // strings are kept verbatim; the engine decides validity at run time and
  // falls back with a recorded reason, so a bad value never blocks a launch.
  const verifierModel = str(verificationRaw.model)
  const verifierEffort = str(verificationRaw.effort)
  // T100: an optional exact-run execution workspace (root-relative). A plain
  // directory inside the project — no absolute path, no "..", no glob. The host
  // additionally requires it to be a git work tree before the run starts.
  const workspace = str(raw.workspace)
  if (workspace && (workspace.startsWith("/") || workspace.split("/").includes("..") || /[*?[\]{}]/.test(workspace)))
    err("workspace", `"${workspace}" must be a plain folder inside the project (no absolute path, ".." or glob)`)

  const scopeRaw = isRecord(raw.scope) ? raw.scope : {}
  const stopRaw = isRecord(raw.stop) ? raw.stop : {}
  const executionRaw = isRecord(raw.execution) ? raw.execution : {}

  // D7: a stop rule phrased as the inverse of continuing ("SHALL NOT continue
  // past X") reads as a stop but encodes a continue. The rule must be phrased
  // positively. This is a WARNING, never an error: a contract that parses today
  // must keep parsing, and the contradiction only needs to be visible at review.
  const inverseStop = /\b(?:shall|must|will)\s+not\s+(?:continue|proceed|keep\s+going|go\s+on)\b|\b(?:do\s+not|don['’]t)\s+continue\b/i
  const stopWhen = str(stopRaw.when).trim()
  if (stopWhen && inverseStop.test(stopWhen))
    warn("stop.when", `stop rule reads as the inverse of continuing: "${stopWhen.slice(0, 160)}" — phrase it positively ("SHALL continue past X") and list what stops the run`)
  for (const [index, entry] of (Array.isArray(stopRaw.escalate_when) ? stopRaw.escalate_when : []).entries()) {
    const rule = str(entry).trim()
    if (rule && inverseStop.test(rule))
      warn(`stop.escalate_when[${index}]`, `escalation rule reads as the inverse of continuing: "${rule.slice(0, 160)}" — phrase it positively ("SHALL continue past X") and list what stops the run`)
  }

  if (issues.some((i) => i.level === "error")) return { issues, lock }
  // T180 — owner-approved contract memory. The outcome and the stop rules are
  // the statements that decide what the loop may conclude, so they are compared
  // against the project's projection of accepted ADRs. A WARNING and a read-only
  // comparison: no error, no rewrite, and no projection means no change at all.
  // Nothing here touches the .cleo store or shells out to the cleo CLI.
  const decisions = options.decisions ?? loadAdrDecisions(options.projectRoot ?? process.cwd())
  if (decisions.length) {
    const fields = [
      { path: "outcome", text: outcome },
      ...(stopWhen ? [{ path: "stop.when", text: stopWhen }] : []),
      ...(Array.isArray(stopRaw.escalate_when) ? stopRaw.escalate_when : []).flatMap((entry: unknown, index: number) => {
        const rule = str(entry).trim()
        return rule ? [{ path: `stop.escalate_when[${index}]`, text: rule }] : []
      }),
    ]
    issues.push(...adrIssues(fields, decisions))
  }
  // T031: supersession pointer — "<slug>@<lock-prefix>", validated but only
  // enforced at /goal start (existence, lock match, mid-flight admission).
  const supersedes = str(raw.supersedes)
  if (supersedes && !/^[a-z0-9][a-z0-9-]{0,63}@[0-9a-f]{8,64}$/.test(supersedes))
    err("supersedes", "must look like \"<slug>@<lock-prefix>\" (the predecessor slug and the first bytes of its run lock)")
  // T061: optional priority, low/medium/high; absent is valid (sorts last).
  const rawPriority = str((raw as Record<string, unknown>).priority)
  if (rawPriority && !PRIORITIES.includes(rawPriority as Priority))
    err("priority", `priority must be one of low, medium, high (or omitted) — got "${rawPriority}"`)

  // v0.5.0 — the optional CLEO linkage. `cleo.tasks` is a list whose entries are
  // either a bare task id (link for reporting) or `{id, acs}` declaring which
  // gate's evidence proves which AC alias. Absent ⇒ no CLEO behaviour change.
  // T171 — `cleo.saga`/`cleo.epics` name the rollup scope, nothing more.
  const cleoTasks: CleoTaskLink[] = []
  let cleoSaga: string | undefined
  const cleoEpics: string[] = []
  if (raw.cleo !== undefined) {
    if (!isRecord(raw.cleo)) err("cleo", "cleo must be a mapping with a tasks list")
    else {
      const sagaRaw = str(raw.cleo.saga)
      if (sagaRaw && !/^[A-Z]{1,4}\d+$/.test(sagaRaw)) err("cleo.saga", `saga id must look like T123 (got "${sagaRaw}")`)
      else if (sagaRaw) cleoSaga = sagaRaw
      const epicsRaw = raw.cleo.epics
      if (epicsRaw !== undefined && !Array.isArray(epicsRaw)) err("cleo.epics", "epics must be a list of epic ids")
      for (const [index, entry] of (Array.isArray(epicsRaw) ? epicsRaw : []).entries()) {
        const epicId = str(entry)
        if (!/^[A-Z]{1,4}\d+$/.test(epicId)) { err(`cleo.epics[${index}]`, `epic id must look like T123 (got "${epicId}")`); continue }
        if (cleoEpics.includes(epicId)) { err(`cleo.epics[${index}]`, `duplicate epic ${epicId}`); continue }
        cleoEpics.push(epicId)
      }
      const tasksRaw = raw.cleo.tasks
      if (tasksRaw !== undefined && !Array.isArray(tasksRaw)) err("cleo.tasks", "tasks must be a list of task ids")
      const seen = new Set<string>()
      for (const [index, entry] of (Array.isArray(tasksRaw) ? tasksRaw : []).entries()) {
        const at = `cleo.tasks[${index}]`
        const taskId = str(typeof entry === "string" ? entry : isRecord(entry) ? entry.id : "")
        if (!/^[A-Z]{1,4}\d+$/.test(taskId)) { err(at, `task id must look like T123 (got "${taskId}")`); continue }
        if (seen.has(taskId)) { err(at, `duplicate task ${taskId}`); continue }
        seen.add(taskId)
        const acsRaw = isRecord(entry) && isRecord((entry as Record<string, unknown>).acs) ? (entry as Record<string, unknown>).acs as Record<string, unknown> : undefined
        const acs: Partial<Record<CleoGate, string[]>> = {}
        if (acsRaw) {
          // v0.5.1 - `acs` is legacy: the precise per-criterion `proves:` binding
          // replaces it. Still read for compatibility, but warned as deprecated.
          warn(`${at}.acs`, "cleo.tasks[].acs is deprecated - declare the binding on the criterion instead, e.g. proves: [\"T123#AC2\"]; the acs map is still read for compatibility")
          for (const [gate, value] of Object.entries(acsRaw)) {
            if (!(CLEO_GATES as readonly string[]).includes(gate)) { err(`${at}.acs.${gate}`, `unknown gate "${gate}"; allowed: ${CLEO_GATES.join(", ")}`); continue }
            const aliases = strings(value).map((a) => a.toUpperCase())
            if (!aliases.length) { err(`${at}.acs.${gate}`, "list at least one AC alias (AC1, AC2, …)"); continue }
            for (const alias of aliases) if (!/^AC\d+$/.test(alias)) err(`${at}.acs.${gate}`, `AC alias must look like AC1 (got "${alias}")`)
            acs[gate as CleoGate] = aliases
          }
        }
        cleoTasks.push({ id: taskId, ...(Object.keys(acs).length ? { acs } : {}) })
      }
    }
  }

  // T171 — the criterion → task map must resolve. `proves: ["T123#AC2"]` on a task
  // that `cleo.tasks` does not name is dead: the bridge only ever visits declared
  // tasks, so the AC would silently stay open. Say so at validation time instead.
  const linkedTaskIds = new Set(cleoTasks.map((t) => t.id))
  // Only a goal that declares a CLEO block is held to the map: without one the
  // refs are inert, and a contract that predates the block must still parse.
  for (const [section, list] of (raw.cleo !== undefined ? [["criteria", criteria], ["invariants", invariants]] as const : []))
    for (const [index, criterion] of list.entries()) {
      const at = `${section}[${index}]`
      for (const ref of criterion.proves ?? []) {
        const refTask = ref.split("#")[0]!
        if (!linkedTaskIds.has(refTask))
          err(`${at}.proves`, `${ref} names ${refTask}, which cleo.tasks does not declare — add it to cleo.tasks or the bridge can never write that evidence`)
        if (!gateForCheck(criterion.check))
          warn(`${at}.proves`, `${ref} is bound to a ${criterion.check.kind} check, whose evidence proves no CLEO gate (diff passes when paths are UNCHANGED; a verifier/human verdict is not implemented/testsPassed evidence) — it will stay open`)
      }
      // A gate-provable criterion with no binding is allowed, but when the goal
      // declares CLEO tasks the owner almost always wants it recorded: warn.
      if (cleoTasks.length && !criterion.proves?.length && gateForCheck(criterion.check))
        warn(`${at}.proves`, `declares no CLEO AC, so this criterion's evidence is not written to any of ${cleoTasks.map((t) => t.id).join(", ")} — add proves: ["T123#AC1"] if it should be`)
    }
  // T169 — optional declared workstreams. A workstream is one CLEO task under
  // this goal, a named worker, and a return the host can check. The task must
  // already be linked in `cleo.tasks`, so the saga mapping lives in one place.
  const workstreams: Workstream[] = []
  const rawWorkstreams = (raw as Record<string, unknown>).workstreams
  if (rawWorkstreams !== undefined) {
    if (!Array.isArray(rawWorkstreams)) err("workstreams", "workstreams must be a list")
    else {
      const seenIds = new Set<string>()
      for (const [index, entry] of rawWorkstreams.entries()) {
        const at = `workstreams[${index}]`
        if (!isRecord(entry)) { err(at, "workstream must be a mapping"); continue }
        const item = entry as Record<string, unknown>
        const wsId = str(item.id).trim()
        if (!/^[a-z0-9][a-z0-9-]{0,39}$/.test(wsId)) { err(`${at}.id`, "id must be a lowercase kebab-case handle"); continue }
        if (seenIds.has(wsId)) { err(`${at}.id`, `duplicate workstream id "${wsId}"`); continue }
        seenIds.add(wsId)
        const wsTitle = str(item.title).trim()
        if (!wsTitle) err(`${at}.title`, "title is required")
        const task = str(item.task).trim()
        if (!/^[A-Z]{1,4}\d+$/.test(task)) err(`${at}.task`, `task must be a CLEO task id like T169 (got "${task}")`)
        else if (!cleoTasks.some((t) => t.id === task)) err(`${at}.task`, `${task} must also be declared in cleo.tasks so the workstream maps to this goal's saga`)
        const worker = str(item.worker).trim()
        // The named address IS the owner's consent to send outward; a wildcard
        // would let a goal broadcast work nobody agreed to receive.
        if (!/^[a-z0-9][a-z0-9-]{1,39}@[a-z0-9][a-z0-9.-]{1,63}$/.test(worker)) err(`${at}.worker`, "worker must be an explicit agent@host address; wildcards are not allowed")
        const doneWhen = str(item.done_when).trim()
        if (!doneWhen) err(`${at}.done_when`, "done_when is required: say what the worker must return")
        const gates: CleoGate[] = []
        if (item.gates !== undefined) {
          if (!Array.isArray(item.gates)) err(`${at}.gates`, "gates must be a list")
          else for (const value of item.gates as unknown[]) {
            const gate = str(value)
            if (!(CLEO_GATES as readonly string[]).includes(gate)) err(`${at}.gates`, `unknown gate "${gate}"; allowed: ${CLEO_GATES.join(", ")}`)
            else if (!gates.includes(gate as CleoGate)) gates.push(gate as CleoGate)
          }
        }
        workstreams.push({ id: wsId, title: wsTitle, task, worker, done_when: doneWhen, ...(gates.length ? { gates } : {}) })
      }
    }
  }

  const contract: Contract = {
    schema: SCHEMA,
    id,
    title,
    ...(rawPriority ? { priority: rawPriority as Priority } : {}),
    ...(supersedes ? { supersedes } : {}),
    intent: { verbatim: intent },
    outcome,
    ...(str(raw.why) ? { why: str(raw.why) } : {}),
    scope: { in: strings(scopeRaw.in), out: strings(scopeRaw.out) },
    non_goals: nonGoals,
    constraints: strings(raw.constraints),
    criteria,
    invariants,
    ...(workspace ? { workspace } : {}),
  ...(cleoTasks.length || cleoSaga || cleoEpics.length ? { cleo: { ...(cleoSaga ? { saga: cleoSaga } : {}), ...(cleoEpics.length ? { epics: cleoEpics } : {}), tasks: cleoTasks } } : {}),
    ...(workstreams.length ? { workstreams } : {}),
    protect: strings(raw.protect),
    assumptions,
    plan,
    budget,
    stop: { ...(str(stopRaw.when) ? { when: str(stopRaw.when) } : {}), escalate_when: strings(stopRaw.escalate_when) },
    autonomy,
    verification: { mode, max_rejections: maxRejections, read: verifierRead, ...(verifierModel ? { model: verifierModel } : {}), ...(verifierEffort ? { effort: verifierEffort } : {}) },
    execution: str(executionRaw.agent) ? { agent: str(executionRaw.agent) } : {},
    meta: isRecord(raw.meta) ? raw.meta : {},
  }
  return { contract, issues, lock }
}

function hasCycle(plan: Step[]): boolean {
  const deps = new Map(plan.map((s) => [s.id, s.depends_on]))
  const state = new Map<string, 1 | 2>()
  const visit = (id: string): boolean => {
    if (state.get(id) === 2) return false
    if (state.get(id) === 1) return true
    state.set(id, 1)
    for (const next of deps.get(id) ?? []) if (deps.has(next) && visit(next)) return true
    state.set(id, 2)
    return false
  }
  return plan.some((s) => visit(s.id))
}

/** Bun's YAML errors carry no position; point at the likeliest culprit. */
function yamlHint(text: string): string {
  const lines = text.split("\n")
  for (let i = 0; i < lines.length; i++) {
    const value = /^\s*(?:- )?[A-Za-z_][\w-]*:\s+([^'"\[{|>#].*)$/.exec(lines[i]!)?.[1]
    if (value && /:\s/.test(value)) return ` (line ${i + 1} has an unquoted value containing ": " — wrap the value in single quotes)`
  }
  return ""
}

export const formatIssues = (issues: Issue[]) => {
  const lines = issues.map((i) => `${i.level === "error" ? "✗" : "!"} ${i.path || "goal.yaml"}: ${i.message}`)
  // A contract with warnings is still valid. Say so, so `validate` never looks
  // like a failure just because it reported an advisory issue (T171).
  if (!issues.some((i) => i.level === "error")) lines.push(`✓ goal.yaml is valid${issues.length ? " (with warnings)" : ""}`)
  return lines.join("\n")
}
