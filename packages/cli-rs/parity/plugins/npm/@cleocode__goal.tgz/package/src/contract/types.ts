// goal/v1: the contract a goal is executed against. Written by the owner (usually
// through the write-goal skill), locked by hash when a run starts, never edited by
// the worker agent.

export const SCHEMA = "goal/v1" as const

export type Expect = {
  exit?: number
  stdout_contains?: string
  stdout_regex?: string
}

export type CommandCheck = { kind: "command"; run: string; expect?: Expect; timeout?: number; runs?: number; live?: boolean }
export type FileCheck = { kind: "file"; path: string; exists?: boolean }
export type ContainsCheck = { kind: "contains"; path: string; text?: string; regex?: string }
export type AbsentCheck = { kind: "absent"; pattern: string; paths?: string[] }
export type DiffCheck = { kind: "diff"; paths: string[] }
export type VerifierCheck = { kind: "verifier"; ask: string }
export type HumanCheck = { kind: "human"; ask: string }

export type Check = CommandCheck | FileCheck | ContainsCheck | AbsentCheck | DiffCheck | VerifierCheck | HumanCheck
export type CheckKind = Check["kind"]

export const HOST_KINDS = ["command", "file", "contains", "absent", "diff"] as const
export const CHECK_KINDS = [...HOST_KINDS, "verifier", "human"] as const
export const isHostCheck = (check: Check): boolean => (HOST_KINDS as readonly string[]).includes(check.kind)

export type Criterion = {
  id: string
  statement: string
  essential: boolean
  check: Check
  /**
   * v0.5.0 — the CLEO acceptance criteria this criterion's evidence demonstrates,
   * `T<id>#AC<n>` (the same form as a `satisfies:` atom). This is the PRECISE,
   * non-positional binding: when the criterion passes, the bridge links its
   * evidence to exactly these ACs. Absent ⇒ the criterion proves no CLEO AC.
   */
  proves?: GoalAcRef[]
}

/**
 * A CLEO acceptance-criterion reference (`proves:` on a criterion). Three
 * `satisfies:` forms are accepted and validated by the parser:
 *   `T1234#AC2`  a bare AC alias
 *   `T1234#<uuid>`  a criterion id
 *   `T1234#AC2@<14-digit pin>`  a pinned AC alias
 * CLEO widened GoalAcRef to all three (agreed 2026-10-16); a locked contract
 * should PREFER the uuid or pinned form, because a bare `AC2` drifts when a
 * task's criteria are renumbered. The type is deliberately loose; the parser
 * (`AC_REF` in parse.ts) is the authority.
 */
export type GoalAcRef = `T${number}#${string}`

export type Assumption = {
  id: string
  text: string
  rationale?: string
  reversible?: boolean
  status: "assumed" | "confirmed" | "vetoed"
}

export type Step = {
  id: string
  title: string
  proves: string[]
  depends_on: string[]
}

/** T061: optional goal priority. Absent is valid and sorts LAST. */
export type Priority = "low" | "medium" | "high"
export const PRIORITIES: readonly Priority[] = ["low", "medium", "high"]
/** Sort weight: high first, absent last, ties by updatedAt descending. */
export const priorityWeight = (p?: Priority): number => (p === "high" ? 3 : p === "medium" ? 2 : p === "low" ? 1 : 0)

export type Budget = {
  turns?: number
  /** Wall-clock budget in milliseconds of active run time. */
  wallMs?: number
  /** Token spend (input + output + reasoning) across the run. */
  tokens?: number
  cost_usd?: number
}

/** Change classes the OWNER lets the agent apply to its own contract. */
export type AmendClass = "timeout" | "budget" | "plan" | "recover"
export const AMEND_CLASSES: readonly AmendClass[] = ["timeout", "budget", "plan", "recover"]

/**
 * T170 — the owner-set autonomy ceiling. One explicit field instead of a
 * hand-tuned bundle, so "how much needs asking?" is a nameable choice.
 *
 * A level is a CEILING, never a grant: an explicit flag in the same block may
 * narrow what the level allows (e.g. `level: standard` + `on_stall: pause`), but
 * it can never widen it (`level: conservative` + `amend: [timeout]` still
 * grants nothing). Absent ⇒ today's behaviour exactly, so no existing contract
 * changes.
 *
 * No level touches the safety stops (src/engine/loop-stop.ts): a human
 * criterion, an outward/destructive act, a real blocker, and a contract/oracle
 * change always stop and ask. Budget and new-project stops keep their own
 * explicit waivers (`continue_past_budget`, `visit_new_projects`) rather than
 * being inferred from a level.
 */
export type AutonomyLevel = "conservative" | "standard" | "full"
export const AUTONOMY_LEVELS: readonly AutonomyLevel[] = ["conservative", "standard", "full"]

/** What each level chooses by default. Explicit flags may only narrow this. */
export const AUTONOMY_LEVEL_POLICY: Record<AutonomyLevel, { on_stall: "pause" | "continue"; amend: readonly AmendClass[] }> = {
  /** Today's defaults: stop on a stall, apply no contract change itself. */
  conservative: { on_stall: "pause", amend: [] },
  /** No routine pause: a stalled-but-active run continues with a recorded
   *  report, and only the reversible routine changes (timeout, in-policy
   *  divergence recovery) are applied by the agent. Everything in AC3 stops. */
  standard: { on_stall: "continue", amend: ["timeout", "recover"] },
  /** Standard plus budget/plan additions inside the contract's own bounds. */
  full: { on_stall: "continue", amend: ["timeout", "budget", "plan", "recover"] },
}

export type Autonomy = {
  questions: "defer" | "allow"
  on_user_message: "steer" | "pause"
  on_interrupt: "pause" | "resume-on-message"
  /** T170: the owner-set autonomy ceiling. Absent ⇒ legacy flag behaviour. */
  level?: AutonomyLevel
  /** Owner-set policy: classes the agent may apply itself (default none). */
  amend: AmendClass[]
  /** Owner-set: what the stall detector does. `pause` (default) stops for the
   * owner; `continue` keeps a stalled-but-active run going with a report. */
  on_stall: "pause" | "continue"
  /** v0.8.0: a first visit to a project this loop has never worked in does not
   * stop it. Default false (the contract's stop rule applies). */
  visit_new_projects?: boolean
  /** v0.8.0: an exhausted budget does not stop the loop. Default false. */
  continue_past_budget?: boolean
}

export type VerificationMode = "host" | "host+verifier" | "strict"

/** v0.5.0 — the optional CLEO linkage block. Absent ⇒ no CLEO behaviour change. */
export const CLEO_GATES = ["implemented", "testsPassed", "qaPassed"] as const
export type CleoGate = (typeof CLEO_GATES)[number]
/**
 * A task the goal serves. The bare id links the task for reporting; `acs` is the
 * DECLARED, non-positional claim of which gate's evidence proves which AC alias.
 * An AC that is not declared (and has no typed gate) is left open and reported.
 */
export type CleoTaskLink = { id: string; acs?: Partial<Record<CleoGate, string[]>> }

/**
 * T171 — the optional CLEO block, extended with the rollup scope. `saga`/`epics`
 * name where the goal's work lands in CLEO's hierarchy so the read-only rollup
 * can report proven vs unproven work for that saga and its epics. They add
 * nothing to what is written: evidence still goes through `cleo verify` only.
 */
export type CleoLinks = { saga?: string; epics?: string[]; tasks: CleoTaskLink[] }

/**
 * T171 — the gate whose evidence CAN demonstrate a criterion, decided by the
 * criterion's OWN check (never its position). Kept beside the types so the
 * parser can warn about a `proves:` binding no gate can ever satisfy, and the
 * bridge uses the same rule. `diff` (a pass means paths are UNCHANGED), a
 * verifier verdict and a human sign-off prove no CLEO gate.
 */
export const gateForCheck = (check: Check): CleoGate | undefined => {
  if (check.kind === "command") return /\btypecheck\b|\blint\b/.test(check.run) ? "qaPassed" : "testsPassed"
  if (check.kind === "file" || check.kind === "contains" || check.kind === "absent") return "implemented"
  return undefined
}

/**
 * T169 — one declared workstream: a CLEO task under this goal, a named worker to
 * do it, and what that worker must return to be believed. Optional and additive:
 * a contract without workstreams behaves exactly as it did before.
 */
export type Workstream = {
  /** Stable handle inside the goal; unique, lowercase kebab-case. */
  id: string
  title: string
  /** The CLEO task it drives; must also be declared in `cleo.tasks`. */
  task: string
  /** Explicit worker address (agent@host). Wildcards are rejected: the owner's
   *  consent to send outward is the named address written in the contract. */
  worker: string
  /** What the worker must return, in words the owner can check. */
  done_when: string
  /** Gates this workstream owns; defaults to the task link's declared gates. */
  gates?: CleoGate[]
}

export type Contract = {
  schema: typeof SCHEMA
  id: string
  title: string
  /** T061: optional low/medium/high ordering across lists, palette and picker. */
  priority?: Priority
  /** T031: "<slug>@<lock-prefix>" — this goal replaces that one (owner-approved append, never a rewrite). */
  supersedes?: string
  intent: { verbatim: string }
  outcome: string
  why?: string
  scope: { in: string[]; out: string[] }
  non_goals: string[]
  constraints: string[]
  criteria: Criterion[]
  invariants: Criterion[]
  /** T100: the exact-run execution workspace (root-relative). Host checks, the
   *  protect/diff base and the fingerprint resolve here; default is the project
   *  root. `.opencode/goals/**` still resolves at the project root. */
  workspace?: string
  /** v0.5.0 — the tasks this goal serves; T171 adds the rollup scope. */
  cleo?: CleoLinks
  /** T169 — declared workstreams; absent ⇒ single-threaded goal, unchanged. */
  workstreams?: Workstream[]
  protect: string[]
  assumptions: Assumption[]
  plan: Step[]
  budget: Budget
  stop: { when?: string; escalate_when: string[] }
  autonomy: Autonomy
  verification: {
    mode: VerificationMode
    max_rejections: number
    read: string[]
    /** T107: the contract names the verifier child's model, "providerID/modelID[#variant]". */
    model?: string
    /** T107: the contract names the verifier child's effort (used as the model variant when the model carries none). */
    effort?: string
  }
  execution: { agent?: string }
  meta: Record<string, unknown>
}

export type Issue = { level: "error" | "warning"; path: string; message: string }
