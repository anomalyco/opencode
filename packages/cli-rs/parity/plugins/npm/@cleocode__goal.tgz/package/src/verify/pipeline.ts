// Completion is decided here, never by the worker. Order: contract integrity →
// host-run checks → independent verifier (with quotes the host re-reads) →
// owner sign-off for human criteria.
import { existsSync, readFileSync } from "node:fs"
import type { Check, Contract, Criterion } from "../contract/types"
import { isHostCheck } from "../contract/types"
import { lockOf } from "../contract/parse"
import type { RunState } from "../engine/state"
import { changedSince, isRepo, matchesAny, storeExcludePaths } from "../util/git"
import { runShell, tail, type ShellResult } from "../util/shell"
import { bindingNote, captureFileDigests, demotionReason, inside, staleBindings, type StaleBinding } from "./evidence"

/**
 * T179: both sides of a host/verifier disagreement, kept verbatim. The old
 * code replaced the host result with a verifier fail, so the verdict could not
 * say what the host had actually observed.
 */
export type Dispute = { host: string; verifier: string; verdict: "not_proven" | "contradicted"; reason?: string }

export type CheckResult = {
  id: string
  pass: boolean
  by: "host" | "verifier" | "verifier-fallback" | "human" | "disputed"
  detail: string
  raw?: unknown
  /** T178: sha256 of every file the verdict cited, captured when it was proven. */
  evidence?: { files: Record<string, string>; at?: number }
  /** T179: present only when the host passed and the verifier did not. */
  dispute?: Dispute
}

export type VerifierVerdict = { id: string; verdict: "proven" | "not_proven" | "contradicted"; reason?: string; evidence: Array<{ path: string; quote: string }> }
export type VerifierRun = (input: { contract: Contract; state: RunState; criteria: Criterion[]; host: CheckResult[] }) => Promise<{ verdicts: VerifierVerdict[]; by?: "verifier" | "verifier-fallback"; error?: string }>

export type VerifyOutcome = {
  passed: boolean
  needsHuman: string[]
  results: CheckResult[]
  integrity: string[]
  lines: string[]
  /** T178: previously proven criteria whose cited bytes moved this round. */
  demotions?: StaleBinding[]
  /** T179: required criteria the host and verifier disagree about. */
  disputed?: string[]
}

export async function runHostCheck(check: Check, root: string, base: string | undefined, shell = runShell): Promise<{ pass: boolean; detail: string; raw?: unknown }> {
  switch (check.kind) {
    case "command": {
      const runs: ShellResult[] = []
      for (let i = 0; i < (check.runs ?? 1); i++) {
        const result = await shell(check.run, root, check.timeout ?? 300)
        runs.push(result)
        const why = failure(check, result)
        if (why) return { pass: false, detail: `run ${i + 1}/${check.runs ?? 1}: ${why}\n${tail(result.stdout + (result.stderr ? `\n[stderr]\n${result.stderr}` : ""))}`, raw: runs }
      }
      const last = runs.at(-1)!
      return { pass: true, detail: `exit ${last.exit} in ${(last.ms / 1000).toFixed(1)}s${(check.runs ?? 1) > 1 ? ` ×${check.runs}` : ""}`, raw: runs }
    }
    case "file": {
      const path = inside(root, check.path)
      if (!path) return { pass: false, detail: `${check.path} is outside the project` }
      const exists = existsSync(path)
      const want = check.exists !== false
      return { pass: exists === want, detail: `${check.path} ${exists ? "exists" : "does not exist"}` }
    }
    case "contains": {
      const path = inside(root, check.path)
      if (!path || !existsSync(path)) return { pass: false, detail: `${check.path} not found` }
      const text = readFileSync(path, "utf8")
      const ok = check.text ? text.includes(check.text) : new RegExp(check.regex!, "m").test(text)
      return { pass: ok, detail: ok ? `${check.path} contains the expected ${check.text ? "text" : "pattern"}` : `${check.path} lacks ${check.text ? `"${check.text}"` : `/${check.regex}/`}` }
    }
    case "absent": {
      const paths = check.paths?.length ? check.paths : ["."]
      const quoted = (s: string) => `'${s.replace(/'/g, `'\\''`)}'`
      // T182: goal state is not evidence — the same resolved exclusion set the
      // fingerprint uses, so a criterion can never be satisfied (or broken) by
      // a run.json or ledger line.
      const excludes = storeExcludePaths(root).map((rel) => quoted(`:(exclude)${rel}`)).join(" ")
      const cmd = isRepo(root)
        ? `git grep -n -I -E -e ${quoted(check.pattern)} -- ${paths.map(quoted).join(" ")} ${excludes}`
        : `grep -rnIE --exclude-dir=node_modules --exclude-dir=.git --exclude-dir=goals -e ${quoted(check.pattern)} ${paths.map(quoted).join(" ")}`
      const result = await shell(cmd, root, 120)
      const matches = result.stdout.trim().split("\n").filter(Boolean)
      if (result.exit > 1) return { pass: false, detail: `search failed (exit ${result.exit}): ${tail(result.stderr, 3)}` }
      return { pass: matches.length === 0, detail: matches.length ? `${matches.length} match(es) remain, e.g.\n${matches.slice(0, 5).join("\n")}` : "no matches" }
    }
    case "diff": {
      const changed = changedSince(root, base).filter((f) => matchesAny(f, check.paths))
      return { pass: changed.length === 0, detail: changed.length ? `changed since start: ${changed.slice(0, 10).join(", ")}` : "unchanged since start" }
    }
    default:
      return { pass: false, detail: `${check.kind} is not a host check` }
  }
}

function failure(check: Extract<Check, { kind: "command" }>, result: ShellResult): string | undefined {
  if (result.timedOut) return `timed out after ${check.timeout ?? 300}s`
  const e = check.expect ?? { exit: 0 }
  if (e.exit !== undefined && result.exit !== e.exit) return `exit ${result.exit}, expected ${e.exit}`
  if (e.stdout_contains && !result.stdout.includes(e.stdout_contains)) return `output lacks "${e.stdout_contains}"`
  if (e.stdout_regex && !new RegExp(e.stdout_regex, "m").test(result.stdout)) return `output does not match /${e.stdout_regex}/`
  return undefined
}

const collapse = (s: string) => s.replace(/\s+/g, " ").trim()

/** T108: JUnit/XML bytes carry entity escapes (`&#10;`, `&quot;`, `&lt;`). A
 * verifier that quotes the *decoded* line it read (a newline, a quote mark) did
 * not match the raw XML, so a correct round was rejected as "quoted text not
 * found" — the live C5 failure. Decode both sides before comparing. */
export function decodeEntities(s: string): string {
  return s
    .replace(/&#x([0-9a-fA-F]+);/g, (m, h) => { try { return String.fromCodePoint(parseInt(h, 16)) } catch { return m } })
    .replace(/&#(\d+);/g, (m, d) => { try { return String.fromCodePoint(Number(d)) } catch { return m } })
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&amp;/g, "&")
}

/** The host re-reads every quote the verifier cites; an unverifiable quote is no
 * evidence. A quote may match the raw bytes or their entity-decoded equivalent,
 * so both the raw junit and a plain-text renderer of the same line are accepted. */
export function checkQuotes(root: string, verdict: VerifierVerdict): { ok: boolean; why?: string } {
  if (verdict.verdict !== "proven") return { ok: false, why: verdict.reason ?? verdict.verdict }
  if (!verdict.evidence.length) return { ok: false, why: "verifier cited no evidence" }
  for (const item of verdict.evidence) {
    const path = inside(root, item.path)
    if (!path || !existsSync(path)) return { ok: false, why: `cited file ${item.path} does not exist` }
    if (!item.quote || collapse(item.quote).length < 8) return { ok: false, why: `quote from ${item.path} is too short to check` }
    const raw = readFileSync(path, "utf8")
    const hit = (hay: string, needle: string) => collapse(hay).includes(collapse(needle))
    if (!hit(raw, item.quote) && !hit(decodeEntities(raw), decodeEntities(item.quote)))
      return { ok: false, why: `quoted text not found in ${item.path} (raw or entity-decoded)` }
  }
  return { ok: true }
}

export async function verifyClaim(contract: Contract, state: RunState, deps: { root: string; contractText: string; verifier?: VerifierRun; shell?: typeof runShell; onProgress?: (activity: RunState["activity"]) => void; environment?: string[] }): Promise<VerifyOutcome> {
  const { root } = deps
  const integrity: string[] = []
  if (lockOf(deps.contractText) !== state.lock)
    integrity.push(
      "goal.yaml changed since the run started: the contract is sha256-locked for this run. The owner re-locks an amended contract with /goal amend confirm (audit-trailed, generation-bound) or aborts and starts fresh; a worker must never edit .opencode/goals/.",
    )
  if (contract.protect.length) {
    const touched = changedSince(root, state.base.commit).filter((f) => matchesAny(f, contract.protect))
    if (touched.length) integrity.push(`protected paths were modified: ${touched.slice(0, 10).join(", ")}. Restore them; do not change the oracle to make it pass.`)
  }

  const results: CheckResult[] = []
  // T178: a verifier proof is bound to the bytes it quoted. Before anything
  // re-runs, name every previously proven criterion whose cited files moved —
  // and demote it in the state so the old pass cannot stand for bytes nobody
  // checked. A host check is exempt: it runs again below and re-establishes its
  // own result, so it is never bound to verifier evidence.
  const verifierIDs = new Set(contract.criteria.filter((c) => c.check.kind === "verifier").map((c) => c.id))
  const demotions = staleBindings(root, state.criteria, verifierIDs)
  for (const binding of demotions) {
    const prior = state.criteria[binding.criterion]
    if (!prior) continue
    state.criteria[binding.criterion] = {
      ...prior,
      status: "stale",
      at: Date.now(),
      detail: demotionReason(binding).slice(0, 600),
    }
  }
  // T057: an owner-approved criterion is final against HOST re-checks too —
  // a stale check (the live C15 needle case) must never stomp an explicit
  // sign-off. The owner outranks every automated re-verification.
  const ownerFinal = (id: string) => state.criteria[id]?.status === "pass" && state.criteria[id]?.by === "human"
  const checkable = [...contract.criteria, ...contract.invariants].filter((c) => isHostCheck(c.check))
  for (const [index, c] of checkable.entries()) {
    if (ownerFinal(c.id)) {
      results.push({ id: c.id, pass: true, by: "human", detail: "approved by the owner (final)" })
      continue
    }
    // T063: the tracer shows live per-criterion progress through the checks
    state.activity = { kind: "verifying", since: state.activity?.since ?? Date.now(), detail: `check ${c.id} · ${index + 1}/${checkable.length}` }
    deps.onProgress?.(state.activity)
    const r = await runHostCheck(c.check, root, state.base.commit, deps.shell)
    results.push({ id: c.id, pass: r.pass, by: "host", detail: r.detail, raw: r.raw })
  }

  const semantic = contract.criteria.filter((c) => c.check.kind === "verifier")
  const strictExtra = contract.verification.mode === "strict" ? contract.criteria.filter((c) => isHostCheck(c.check) && results.find((r) => r.id === c.id)?.pass) : []
  // T051: an owner-approved criterion (pass by:human) is final — the owner
  // outranks the verifier, so re-verification must respect it permanently
  // instead of re-running a child that can stomp an explicit sign-off.
  const toVerify = (contract.verification.mode === "host" ? [] : [...semantic, ...strictExtra]).filter((c) => !ownerFinal(c.id))
  for (const c of [...semantic, ...strictExtra]) {
    if (ownerFinal(c.id) && !results.some((r) => r.id === c.id))
      results.push({ id: c.id, pass: true, by: "human", detail: "approved by the owner (final)" })
  }
  if (toVerify.length) {
    if (!deps.verifier) {
      for (const c of toVerify) results.push({ id: c.id, pass: false, by: "verifier", detail: "verifier unavailable; failing closed" })
    } else {
      const run = await deps.verifier({ contract, state, criteria: toVerify, host: results }).catch((error) => ({ verdicts: [] as VerifierVerdict[], by: "verifier" as const, error: String(error) }))
      for (const c of toVerify) {
        const v = run.verdicts.find((x) => x.id === c.id)
        const checked = v ? checkQuotes(root, v) : { ok: false, why: run.error ? `verifier failed: ${run.error}` : "verifier returned no verdict" }
        const prior = results.findIndex((r) => r.id === c.id)
        const by: CheckResult["by"] = run.by === "verifier-fallback" ? "verifier-fallback" : "verifier"
        // T178: a proven verdict is bound to the exact bytes the host just
        // re-read. The digests ride in the result so the state can hold them.
        const evidence = checked.ok && v ? { files: captureFileDigests(root, v.evidence.map((e) => e.path)), at: Date.now() } : undefined
        const entry: CheckResult = {
          id: c.id,
          pass: checked.ok,
          by,
          detail: checked.ok ? `proven with ${v!.evidence.length} quote(s)${run.by === "verifier-fallback" ? " (parsed fallback verdict)" : ""}${bindingNote(evidence!.files)}` : checked.why ?? "not proven",
          ...(evidence ? { evidence } : {}),
          raw: v,
        }
        if (prior >= 0) {
          const hostSide = results[prior]!
          // T179: the host ran its check and passed; the verifier then said the
          // criterion is not proven. That is a disagreement between two honest
          // machines — record both sides as `disputed` and let the owner decide,
          // instead of folding it into a plain verifier fail.
          if (v && (v.verdict === "not_proven" || v.verdict === "contradicted")) {
            results[prior] = {
              id: c.id,
              pass: false,
              by: "disputed",
              detail: `host passed but the verifier says ${v.verdict}${v.reason ? `: ${v.reason}` : ""}`,
              dispute: { host: hostSide.detail, verifier: entry.detail, verdict: v.verdict, ...(v.reason ? { reason: v.reason } : {}) },
              raw: v,
            }
            continue
          }
          // strict mode: the verifier must agree with the passing host check
          if (!checked.ok) results[prior] = { ...entry, detail: `host passed but verifier disagrees: ${entry.detail}` }
        } else results.push(entry)
      }
    }
  }

  const needsHuman = contract.criteria.filter((c) => c.check.kind === "human" && !(state.criteria[c.id]?.status === "pass" && state.criteria[c.id]?.by === "human")).map((c) => c.id)
  for (const c of contract.criteria.filter((c) => c.check.kind === "human")) {
    const s = state.criteria[c.id]
    results.push({ id: c.id, pass: s?.status === "pass" && s.by === "human", by: "human", detail: s?.status === "pass" ? "approved by the owner" : "awaiting owner sign-off" })
  }

  const required = new Set([...contract.criteria.filter((c) => c.essential).map((c) => c.id), ...contract.invariants.map((c) => c.id)])
  const failed = results.filter((r) => required.has(r.id) && !r.pass && r.by !== "human")
  // T179: a host/verifier disagreement is not a plain fail — it is a question
  // for the owner. `passed` still cannot be true while one is open.
  const disputed = results.filter((r) => r.by === "disputed" && required.has(r.id)).map((r) => r.id)
  // T178: a demoted criterion only blocks when this round did not re-prove it.
  const reProven = new Set(results.filter((r) => r.pass).map((r) => r.id))
  const staleOpen = demotions.filter((d) => !reProven.has(d.criterion))
  const passed = integrity.length === 0 && failed.length === 0 && needsHuman.filter((id) => required.has(id)).length === 0 && disputed.length === 0 && staleOpen.length === 0

  const lines: string[] = []
  // The environment is not a criterion: it is context a human needs to judge a
  // verdict. A version bump or a HEAD move between turns is named here instead
  // of silently standing behind a "pass" stamped on the previous tree.
  for (const line of deps.environment ?? []) lines.push(line)
  for (const i of integrity) lines.push(`INTEGRITY: ${i}`)
  // T179: name BOTH sides of every disagreement before the ordinary failures.
  for (const r of results) {
    if (r.by !== "disputed" || !r.dispute) continue
    const c = [...contract.criteria, ...contract.invariants].find((x) => x.id === r.id)
    const host = r.dispute.host.replace(/\n/g, "\n      ")
    const verifier = r.dispute.verifier.replace(/\n/g, "\n      ")
    lines.push(
      `${r.id} DISPUTED ${required.has(r.id) ? "" : "(optional) "}[host × verifier] ${c?.statement ?? ""}\n    host passed: ${host}\n    verifier said ${r.dispute.verdict}${r.dispute.reason ? `: ${r.dispute.reason}` : ""}: ${verifier}`,
    )
  }
  // T178: the old proof is gone by name, not silently carried forward.
  const named = new Set<string>()
  for (const binding of staleOpen) {
    if (named.has(binding.criterion)) continue
    named.add(binding.criterion)
    const c = [...contract.criteria, ...contract.invariants].find((x) => x.id === binding.criterion)
    lines.push(`${binding.criterion} STALE ${required.has(binding.criterion) ? "" : "(optional) "}[verifier] ${c?.statement ?? ""}\n    ${demotionReason(binding)}. Re-prove it against the current bytes.`)
  }
  for (const r of results) {
    if (r.pass || r.by === "disputed") continue
    const c = [...contract.criteria, ...contract.invariants].find((x) => x.id === r.id)
    lines.push(`${r.id} ${required.has(r.id) ? "FAILED" : "not met (optional)"} [${r.by}] ${c?.statement ?? ""}\n    ${r.detail.replace(/\n/g, "\n    ")}`)
  }
  if (!lines.length) lines.push("All required criteria passed.")
  return { passed, needsHuman, results, integrity, lines, demotions, disputed }
}
