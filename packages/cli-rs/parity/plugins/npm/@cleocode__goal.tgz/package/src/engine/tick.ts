// v0.7.0 - the `ocg tick` entry point: RECORD the turn, DECIDE, then act.
//
// CLEO's Stop dispatcher spawns `ocg tick` with the harness's Stop JSON on stdin
// and reads JSON ONLY from stdout:
//   {"decision":"block","reason":"<continuation>"}  keep the agent working
//   {"final":false}                                 hold the session open
//   anything else (including non-JSON, or nothing)  no live goal
// Logs go to stderr. It runs only where `.opencode/goals/` exists.
//
// v0.6.0 made the tick decide; it was read-only, so nothing advanced the counters
// the stall, recovery, wrap-up and claim decisions read - a goal could never be
// driven to an end outside OpenCode. v0.7.0 records the turn first (through OCG's
// own store, in the adapter's own shape) and RUNS the verification of a claim, so
// a host-only goal can actually reach `complete`. Everything it records is what a
// Stop-time observer can know or recover from the payload - never a guess, and a
// missing payload, transcript or store is a stated degradation, not an error.

import { existsSync } from "node:fs"
import { join } from "node:path"
import type { Contract } from "../contract/types"
import { renderTailNote, type TailKind } from "../contract/render"
import { budgetUse, setStatus, TERMINAL as TERMINAL_STATUSES, type RunState } from "./state"
import { continuationTail, decide, type LoopLimits, type LoopSignals } from "./loop"
import { recordTurn } from "./tick-record"
import { tickAdapter, type HarnessAdapter, type HarnessName } from "./harness"
import { resolveStoreRoots } from "./store-root"
import type { RunWriteOutcome } from "./store"
import type { VerifyOutcome } from "../verify/pipeline"

/** The plugin's own defaults, so a tick agrees with the adapter unless overridden. */
export const TICK_LIMITS: LoopLimits = { blockerRepeats: 3, stallTurns: 3, recoveryAt: 2, backstopTurns: 200 }
export const TICK_COOLDOWN_MS = 1_500
/** CLEO caps a forwarded reason at 4000 characters. */
export const REASON_CAP = 4_000

/** The store surface the tick writes through - OCG's own store, never a hand edit. */
export type TickStore = {
  slugs: () => string[]
  readRun: (slug: string) => RunState | undefined
  /** T172: a refusal (newer on-disk generation) is reported, never swallowed. */
  writeRun: (state: RunState) => RunWriteOutcome | void
  readContract: (slug: string) => { contract?: Contract; text: string } | undefined
  ledger: (slug: string, event: Record<string, unknown> & { type: string }) => void
  evidence: (slug: string, runId: string, name: string, data: unknown) => string
}

export type TickDeps = {
  root: string
  store: TickStore
  /** The repository fingerprint now (git), or undefined when it cannot be taken. */
  fingerprint?: () => string | undefined
  /** Run the claim verification. Absent means the tick cannot finish a goal. */
  verify?: (state: RunState, contract: Contract, contractText: string) => Promise<VerifyOutcome>
  /** The raw harness Stop payload, when the harness passed one. */
  payload?: string
  /** The dispatcher's environment. Defaults to the real one. */
  env?: Record<string, string | undefined>
  readTranscript?: (path: string) => string | undefined
  limits?: LoopLimits
  cooldownMs?: number
  now?: number
  /** The declared harness. Defaults to the tick adapter for the real environment. */
  harness?: HarnessAdapter
}

export type TickResult = {
  /** Exactly what goes to stdout (empty when no goal is live). */
  stdout: string
  /** Lines for stderr. */
  log: string[]
  /** The harness this tick declared (from CLEO_HOOK_PROVIDER), never guessed. */
  harness: HarnessName
}

const HOLD = JSON.stringify({ final: false })
const why = (error: unknown): string => (error instanceof Error ? error.message : String(error))

/** The newest non-terminal run in the project, by `updatedAt`.
 *
 * An absent or unreadable store is a stated degradation, never an exception: a
 * crash looks exactly like "no live goal" to the dispatcher (empty stdout), which
 * would silently drop the run. If a record cannot be read we cannot rule out a
 * live goal, so the caller HOLDS rather than printing nothing. */
function liveRun(store: TickStore, log: string[]): { live?: RunState; unreadable: boolean } {
  let slugs: string[]
  try {
    slugs = store.slugs()
  } catch (error) {
    log.push(`could not read the run store (${why(error)}); cannot rule out a live goal`)
    return { unreadable: true }
  }
  let live: RunState | undefined
  let unreadable = false
  for (const slug of slugs) {
    let state: RunState | undefined
    try {
      state = store.readRun(slug)
    } catch (error) {
      log.push(`could not read the run record for ${slug} (${why(error)}); cannot rule it out`)
      unreadable = true
      continue
    }
    if (!state?.slug || TERMINAL_STATUSES.includes(state.status)) continue
    if (!live || (state.updatedAt ?? 0) > (live.updatedAt ?? 0)) live = state
  }
  return { live, unreadable }
}

export async function tick(deps: TickDeps): Promise<TickResult> {
  const log: string[] = []
  const now = deps.now ?? Date.now()
  const limits = deps.limits ?? TICK_LIMITS
  // The one seam: the tick is the CLEO Stop-dispatch adapter, and its identity is
  // whatever the dispatcher declared. It is read once, before any decision, so a
  // Stop payload can never rename it.
  const adapter = deps.harness ?? tickAdapter(deps.env ?? process.env)
  const identity = adapter.identity()
  const harness = identity.name
  // Keep the agent working through the adapter's own continuation surface, so the
  // tick and the in-process path share the mechanism as well as the decision.
  const block = (tail: TailKind, reason: string): string => {
    const surface = adapter.continuation(tail, reason)
    if (surface.kind !== "stop-block") throw new Error(`${adapter.name} cannot continue a session through the Stop dispatcher`)
    return surface.payload
  }
  // T172: the tick must never overwrite a run row it has not observed. A
  // refusal is a stated stop, not a silent no-op: the store journals the
  // receipt and this line carries the same fact to the dispatcher's log.
  const write = (state: RunState): boolean => {
    const outcome = deps.store.writeRun(state)
    if (!outcome || outcome.written) return true
    if (outcome.journalled)
      log.push(`refused to overwrite a newer run.json for ${state.slug}: this tick holds generation ${outcome.mine.revision}, disk is generation ${outcome.disk.revision} (${outcome.reason}); the disk bytes were left untouched and a stale-write receipt was journalled`)
    return false
  }
  // Outside a goal project there is nothing to tick at all - print nothing.
  // T150: the active store is canonical by default; a project that has not
  // migrated yet still lives in the legacy store, so either one counts.
  let storeRoots: ReturnType<typeof resolveStoreRoots>
  try {
    storeRoots = resolveStoreRoots(deps.root)
  } catch (error) {
    log.push(`the goal-store configuration cannot be resolved (${why(error)}); holding`)
    return { stdout: HOLD, log, harness }
  }
  if (!existsSync(storeRoots.goals) && !existsSync(storeRoots.legacy.goals)) {
    log.push("no .opencode/goals or .cleo/goals directory; nothing to tick")
    return { stdout: "", log, harness }
  }
  const { live, unreadable } = liveRun(deps.store, log)
  if (!live && unreadable) {
    log.push("a run record could not be read; cannot rule out a live goal - holding")
    return { stdout: HOLD, log, harness }
  }
  if (!live) {
    log.push("no live goal here; nothing to tick")
    return { stdout: "", log, harness }
  }
  log.push(`harness ${identity.name}: ${identity.capabilities ? identity.capabilities.join(", ") : "capabilities not declared by the dispatcher"}`)
  let read: { contract?: Contract; text: string } | undefined
  try {
    read = deps.store.readContract(live.slug)
  } catch (error) {
    log.push(`could not read the contract for ${live.slug} (${why(error)}); holding`)
    return { stdout: HOLD, log, harness }
  }
  if (!read?.contract) {
    log.push(`goal ${live.slug} has no readable contract; holding`)
    return { stdout: HOLD, log, harness }
  }
  const contract = read.contract

  // ── 1. RECORD the turn, through OCG's own store, in the adapter's own shape.
  const record = recordTurn(live, contract, { fingerprint: deps.fingerprint ?? (() => undefined), ...(deps.payload ? { payload: deps.payload } : {}), ...(deps.readTranscript ? { readTranscript: deps.readTranscript } : {}), now })
  // ── 1a. DECLARE the harness that produced this run, once. CLEO's dispatcher
  // names it (`CLEO_HOOK_PROVIDER`); absent or unrecognised is `unknown`, never a
  // guess from the payload. A run already carries its producer, so it is never
  // renamed by a later tick. The identity comes from the same adapter that
  // produced the continuation, so the seam owns both.
  if (!live.harness) {
    live.harness = identity
    deps.store.ledger(live.slug, { type: "harness", name: identity.name, version: identity.version, capabilities: identity.capabilities, source: "tick" })
    log.push(`recorded harness ${identity.name}${identity.name === "unknown" ? " (no CLEO_HOOK_PROVIDER declared)" : ""}`)
  } else if (live.harness.name !== identity.name && identity.name !== "unknown") {
    log.push(`harness is already recorded as ${live.harness.name}; the dispatcher declared ${identity.name} - keeping the producer`)
  }
  deps.store.ledger(live.slug, {
    type: "turn",
    turn: live.turn,
    kind: "tick",
    tools: live.turnFacts.tools,
    activity: live.turnFacts.tools > 0,
    changed: record.changed,
    progress: record.progress,
    noProgress: live.counters.noProgress,
  })
  if (!write(live)) return { stdout: HOLD, log, harness }
  log.push(`recorded turn ${record.turn} for ${live.slug} (${record.progress ? "progress" : "no progress"}${record.claimHonoured ? ", claim honoured" : ""})`)
  for (const gap of record.couldNotSee) log.push(`could not see ${gap}`)

  // ── 2. DECIDE, with the same pure function the OpenCode adapter uses.
  const signals: LoopSignals = {
    turn: "succeeded",
    ...(live.pending ? { pending: live.pending.kind } : {}),
    changed: record.changed,
    progressRecorded: record.progress,
    stepsChanged: false,
    activeStalled: false,
    stallReason: `stalled: no change the host could see for ${live.counters.noProgress} turns`,
    onStall: contract.autonomy.on_stall,
    budgetRatio: budgetUse(live, contract).ratio,
    backstop: false,
    cooldownMs: deps.cooldownMs ?? TICK_COOLDOWN_MS,
    now,
  }
  const action = decide(live, signals, limits)

  // ── 3. ACT.
  switch (action.kind) {
    case "verify": {
      if (!deps.verify) {
        log.push("a claim is pending but this tick cannot verify; holding")
        return { stdout: HOLD, log, harness }
      }
      live.claim = undefined
      setStatus(live, "verifying", "tick verification")
      deps.store.ledger(live.slug, { type: "verify-start", source: "claim", turn: live.turn })
      if (!write(live)) return { stdout: HOLD, log, harness }
      const outcome = await deps.verify(live, contract, read.text)
      const demoted = new Set((outcome.demotions ?? []).map((d) => d.criterion))
      for (const r of outcome.results) {
        const prev = live.criteria[r.id]
        const status = r.pass ? "pass" : r.by === "disputed" ? "disputed" : demoted.has(r.id) ? "stale" : "fail"
        live.criteria[r.id] = { status, by: r.by, at: now, detail: r.detail.slice(0, 600), rejections: prev?.rejections ?? 0, ...(r.evidence ? { evidence: r.evidence } : !r.pass && prev?.evidence ? { evidence: prev.evidence } : {}) }
      }
      live.verdict = { passed: outcome.passed, lines: outcome.lines.slice(0, 20), at: now, turn: live.turn }
      deps.store.evidence(live.slug, live.runId, `verify-tick-${live.turn}`, outcome)
      // T179: no verifier child here, but a disputed outcome (from a verify that
      // did run one) still stops for the owner instead of folding into a fail.
      const disputed = outcome.results.filter((r) => r.by === "disputed").map((r) => r.id)
      if (disputed.length) {
        setStatus(live, "needs_review", `host and verifier disagree on ${disputed.join(", ")}`)
        deps.store.ledger(live.slug, { type: "disputed", criteria: disputed, turn: live.turn })
        if (!write(live)) return { stdout: HOLD, log, harness }
        log.push(`goal ${live.slug} needs an owner decision: host and verifier disagree on ${disputed.join(", ")}`)
        return { stdout: HOLD, log, harness }
      }
      if (outcome.passed) {
        setStatus(live, "complete", "all required criteria verified")
        deps.store.ledger(live.slug, { type: "complete", turn: live.turn })
        // A completion this tick could not record is not reported as complete.
        if (!write(live)) return { stdout: HOLD, log, harness }
        log.push(`goal ${live.slug} complete: ${outcome.lines[0] ?? "all required criteria verified"}`)
        return { stdout: "", log, harness } // no live goal remains; the harness session may end
      }
      // Not proven: keep the run going and hand the agent the verdict.
      setStatus(live, "running")
      if (!write(live)) return { stdout: HOLD, log, harness }
      log.push(`goal ${live.slug} did not pass verification: ${outcome.lines.slice(0, 2).join(" ").slice(0, 200)}`)
      return { stdout: block("verdict", renderTailNote(live, contract, "verdict", now).slice(0, REASON_CAP)), log, harness }
    }
    case "admit":
    case "schedule": {
      const tail = continuationTail(action)!
      if (!write(live)) return { stdout: HOLD, log, harness }
      const reason = renderTailNote(live, contract, tail, now).slice(0, REASON_CAP)
      log.push(`goal ${live.slug}: decision ${action.kind}; continuing with the ${tail} continuation (${reason.length} chars)`)
      return { stdout: block(tail, reason), log, harness }
    }
    default: {
      if (action.kind === "stop") setStatus(live, action.status, action.reason)
      if (!write(live)) return { stdout: HOLD, log, harness }
      log.push(`goal ${live.slug}: decision ${action.kind}${action.kind === "stop" ? ` (${action.code})` : ""}; holding the session`)
      return { stdout: HOLD, log, harness }
    }
  }
}
