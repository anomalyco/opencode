// Worktree fingerprints: progress is measured by authoritative state change,
// not by how much the model talked.
import { spawnSync } from "node:child_process"
import { createHash } from "node:crypto"
import { statSync } from "node:fs"
import { CANONICAL_ARCHIVE_REL, CANONICAL_GOALS_REL, LEGACY_ARCHIVE_REL, LEGACY_GOALS_REL, goalStatePaths, resolveStoreRoots } from "../engine/store-root"

/** Pre-T182 rule, still used by `changedSince` where a protect/diff check must
 *  keep reporting edits made through the legacy path. */
const LEGACY_GOAL_STATE = ":(exclude).opencode/goals"

/** T182: the goal-state paths this project resolves, as project-relative POSIX
 *  paths — active store, its archive, and the legacy pair. Resolved, never
 *  hardcoded, so a project pinning its own root through `.cleo/goal-store.json`
 *  is covered. A config the resolver rejects falls back to the built-in roots
 *  instead of breaking the measurement. */
export function storeExcludePaths(cwd: string): string[] {
  try {
    return goalStatePaths(resolveStoreRoots(cwd))
  } catch {
    return [CANONICAL_GOALS_REL, CANONICAL_ARCHIVE_REL, LEGACY_GOALS_REL, LEGACY_ARCHIVE_REL]
  }
}

/** The same set as git pathspec exclusions, for a `--` pathspec list. */
const storePathspecs = (cwd: string) => storeExcludePaths(cwd).map((rel) => `:(exclude)${rel}`)

function git(cwd: string, args: string[]): { ok: boolean; out: string } {
  // node:child_process so the bin also runs on plain Node (Bun implements it too).
  const result = spawnSync("git", args, { cwd, encoding: "utf8", stdio: ["ignore", "pipe", "pipe"], maxBuffer: 64 * 1024 * 1024 })
  return { ok: result.status === 0, out: result.stdout ?? "" }
}

export const isRepo = (cwd: string) => git(cwd, ["rev-parse", "--is-inside-work-tree"]).out.trim() === "true"

/** T100: the working-tree root for `cwd` (the linked worktree's own root when
 *  cwd is inside one). Used to require a bound workspace to BE a work-tree root
 *  rather than any subdirectory of the project. */
export const topLevel = (cwd: string): string | undefined => {
  const r = git(cwd, ["rev-parse", "--show-toplevel"])
  return r.ok ? r.out.trim() : undefined
}

export const headCommit = (cwd: string): string | undefined => {
  const r = git(cwd, ["rev-parse", "HEAD"])
  return r.ok ? r.out.trim() : undefined
}

/** T183: resolve a revision (HEAD, a sha, a ref) to one full commit sha.
 *  `--end-of-options` keeps a revision from being read as a git option; a
 *  leading "-" is refused before git ever sees it. */
export const resolveCommit = (cwd: string, rev: string): string | undefined => {
  const trimmed = rev.trim()
  if (!trimmed || trimmed.startsWith("-") || !isRepo(cwd)) return undefined
  const r = git(cwd, ["rev-parse", "--verify", "--quiet", "--end-of-options", `${trimmed}^{commit}`])
  return r.ok ? r.out.trim() || undefined : undefined
}

/** Hash of one worktree's staged/unstaged diff plus untracked file sizes and
 *  mtimes, excluding every goal store root (T182: goal-state writes are not
 *  progress, whichever layout the project resolved). */
function treeState(cwd: string): string {
  const exclude = storePathspecs(cwd)
  const diff = git(cwd, ["diff", "HEAD", "--no-color", "--", ".", ...exclude]).out
  const untracked = git(cwd, ["ls-files", "--others", "--exclude-standard", "--", ".", ...exclude]).out
  const contents = untracked
    .split("\n")
    .filter(Boolean)
    .slice(0, 500)
    .map((file) => {
      try {
        const stat = statSync(`${cwd}/${file}`)
        return `${file}:${stat.size}:${Math.trunc(stat.mtimeMs)}`
      } catch {
        return file
      }
    })
  return createHash("sha256").update(diff).update(contents.join("\n")).digest("hex").slice(0, 20)
}

/** T116: linked worktrees live under the project but their work is invisible to
 *  the root worktree's diff, so a run recorded changed:false and tripped the
 *  stall auto-pause. `git worktree list --porcelain` names every worktree; the
 *  signature now carries HEAD/branch AND the dirty state of each linked
 *  worktree, so uncommitted work counts as progress too, not only commits.
 *  The cwd worktree is skipped because `fingerprint` hashes it separately. */
export function worktreeSignature(cwd: string): string {
  const self = topLevel(cwd) ?? cwd
  const blocks = git(cwd, ["worktree", "list", "--porcelain"]).out.split(/\n\s*\n/).map((b) => b.trim()).filter(Boolean)
  return blocks
    .map((block) => {
      const lines = block.split("\n").map((line) => line.trim()).filter(Boolean)
      const path = lines.find((line) => line.startsWith("worktree "))?.slice("worktree ".length)
      if (!path) return block
      if (path === self) return block
      return `${block}\n${treeState(path)}`
    })
    .join("\n\n")
}

/** Hash of HEAD + staged/unstaged diff + untracked file list + every linked
 *  worktree's HEAD and dirty state, excluding goal state. */
export function fingerprint(cwd: string): string | undefined {
  if (!isRepo(cwd)) return undefined
  const head = git(cwd, ["rev-parse", "HEAD"]).out
  return createHash("sha256").update(head).update(treeState(cwd)).update(worktreeSignature(cwd)).digest("hex").slice(0, 20)
}

/** T109: a bounded, host-computed git history digest. The verifier child has only
 * read/glob/grep (no shell), so a criterion that asks about commit history was
 * unanswerable and burned the round budget. The host supplies this text; the
 * verifier judges from it and from the copy the host saves under evidence/. */
export function gitDigest(cwd: string, limit = 20): string {
  if (!isRepo(cwd)) return "(not a git repository)"
  const head = git(cwd, ["rev-parse", "HEAD"]).out.trim()
  const branch = git(cwd, ["rev-parse", "--abbrev-ref", "HEAD"]).out.trim()
  const log = git(cwd, ["log", "-n", String(limit), "--no-color", "--pretty=format:%h %ad %s", "--date=short"]).out.trim()
  const trees = worktreeSignature(cwd)
  return [`HEAD ${head}`, `branch ${branch}`, log, trees ? `linked worktrees:\n${trees}` : ""].filter(Boolean).join("\n")
}

/** Files changed relative to `base` (committed, staged, unstaged and untracked).
 *  Only the legacy store is excluded here: `protect` and `diff` checks judge
 *  edits, not progress, so they keep seeing the resolved store. */
export function changedSince(cwd: string, base: string | undefined): string[] {
  if (!isRepo(cwd)) return []
  const files = new Set<string>()
  if (base) for (const f of git(cwd, ["diff", "--name-only", base, "--", ".", LEGACY_GOAL_STATE]).out.split("\n")) if (f) files.add(f)
  for (const f of git(cwd, ["diff", "--name-only", "HEAD", "--", ".", LEGACY_GOAL_STATE]).out.split("\n")) if (f) files.add(f)
  for (const f of git(cwd, ["ls-files", "--others", "--exclude-standard", "--", ".", LEGACY_GOAL_STATE]).out.split("\n")) if (f) files.add(f)
  return [...files].sort()
}

/** Minimal glob → RegExp (supports **, *, ?). */
export function globToRegExp(glob: string): RegExp {
  let re = ""
  for (let i = 0; i < glob.length; i++) {
    const c = glob[i]!
    if (c === "*") {
      if (glob[i + 1] === "*") {
        re += glob[i + 2] === "/" ? "(?:.*/)?" : ".*"
        i += glob[i + 2] === "/" ? 2 : 1
      } else re += "[^/]*"
    } else if (c === "?") re += "[^/]"
    else re += c.replace(/[.+^${}()|[\]\\]/g, "\\$&")
  }
  return new RegExp(`^${re}$`)
}

export const matchesAny = (file: string, globs: string[]) => globs.some((g) => globToRegExp(g.replace(/^\.\//, "")).test(file))
