// Shared server↔TUI contract. A plain object (Rpc.define is an identity
// function), so neither side needs @opencode/plugin at runtime.
const anyObject = { type: "object", additionalProperties: true } as const
import type { CriterionStatus, Handoff } from "./engine/state"
import type { HarnessIdentity } from "./engine/harness-identity"
import type { LaunchView } from "./engine/launches"
export type { LaunchView } from "./engine/launches"
// V2 RPC's schema adapter rejects regex patterns. Length is declared here;
// the host validates hex syntax AND exact target identity before execution.
const targetObject = { type: "object", properties: { key: { type: "string", minLength: 1, maxLength: 256 }, lock: { type: "string", minLength: 64, maxLength: 64 }, runId: { type: "string", minLength: 1, maxLength: 128 }, sessionID: { type: "string", minLength: 1, maxLength: 256 } }, required: ["key", "lock"], additionalProperties: false } as const

export const GoalRpc = {
  id: "open-goal",
  methods: {
    provenance: {
      input: { type: "object", properties: { sessionID: { type: "string", minLength: 1, maxLength: 256 } }, additionalProperties: false },
      output: anyObject,
    },
    snapshot: {
      input: { type: "object", properties: { sessionID: { type: "string", minLength: 1, maxLength: 256 } }, required: ["sessionID"], additionalProperties: false },
      output: anyObject,
    },
    list: {
      input: { type: "object", properties: {}, additionalProperties: false },
      output: anyObject,
    },
    details: {
      input: { type: "object", properties: { key: { type: "string", minLength: 1, maxLength: 256 } }, required: ["key"], additionalProperties: false },
      output: anyObject,
    },
    review: {
      input: { type: "object", properties: { sessionID: { type: "string", minLength: 1, maxLength: 256 }, decisionId: { type: "string", minLength: 1, maxLength: 256 } }, required: ["sessionID"], additionalProperties: false },
      output: anyObject,
    },
    manage: {
      input: { type: "object", properties: { sessionID: { type: "string", minLength: 1, maxLength: 256 }, action: { type: "string", enum: ["pause", "resume", "verify", "attach", "abort", "archive", "rebase"] }, target: targetObject, commit: { type: "string", minLength: 1, maxLength: 200 } }, required: ["sessionID", "action", "target"], additionalProperties: false },
      output: anyObject,
    },
    migrate: {
      input: { type: "object", properties: { sessionID: { type: "string", minLength: 1, maxLength: 256 }, confirm: { type: "boolean" } }, required: ["sessionID"], additionalProperties: false },
      output: anyObject,
    },
    act: {
      input: {
        type: "object",
        properties: {
          sessionID: { type: "string", minLength: 1, maxLength: 256 },
          action: { type: "string", enum: ["pause", "resume", "abort", "verify", "approve", "reject", "amend", "archive", "attach", "start", "start-next", "decompose", "rebase", "migrate"] },
          arg: { type: "string", maxLength: 2000 },
          decisionId: { type: "string", minLength: 1, maxLength: 256 },
        },
        required: ["sessionID", "action"],
        additionalProperties: false,
      },
      output: anyObject,
    },
  },
  events: {
    handoff: { schema: { type: "object", properties: { fromSessionID: { type: "string" }, toSessionID: { type: "string" }, slug: { type: "string" }, runId: { type: "string" }, fallback: { type: "string" } }, required: ["fromSessionID", "toSessionID", "slug", "runId"], additionalProperties: false } },
    updated: { schema: { type: "object", properties: { sessionID: { type: "string" }, view: anyObject }, required: ["sessionID"], additionalProperties: true } },
    notice: { schema: { type: "object", properties: { sessionID: { type: "string" }, level: { type: "string" }, text: { type: "string" }, attention: { type: "string" } }, required: ["text"], additionalProperties: true } },
    summary: { schema: { type: "object", properties: { sessionID: { type: "string" }, slug: { type: "string" }, status: { type: "string" }, headline: { type: "string" }, title: { type: "string" }, digest: { type: "string" }, text: { type: "string" } }, required: ["sessionID", "text"], additionalProperties: true } },
    decision: {
      schema: {
        type: "object",
        properties: {
          sessionID: { type: "string" },
          slug: { type: "string" },
          kind: { type: "string", enum: ["needs_review", "paused-after-verdict", "blocked", "budget_limited", "backstop_limited", "amend-proposed", "supersede-ack", "complete", "start-picker", "owner-operation"] },
          title: { type: "string" },
          message: { type: "string" },
          question: { type: "string" },
          expiresAt: { type: "number" },
          choices: { type: "array", items: { type: "object", properties: { label: { type: "string" }, act: { type: "string" }, arg: { type: "string" }, run: { type: "string" } }, required: ["label"], additionalProperties: true } },
        },
        required: ["sessionID", "kind", "message", "choices"],
        additionalProperties: true,
      },
    },
    // T075: whichever surface answered a decision (native form or TUI
    // dialog) — live TUIs close their open dialog on it (suppression).
    "decision.resolved": {
      schema: {
        type: "object",
        properties: {
          sessionID: { type: "string" },
          kind: { type: "string" },
          decisionId: { type: "string" },
          via: { type: "string", enum: ["form", "dialog", "form-guidance", "amendment-invalidated"] },
        },
        required: ["sessionID", "kind", "via"],
        additionalProperties: true,
      },
    },
    "decision.failed": {
      schema: { type: "object", properties: { sessionID: { type: "string" }, decisionId: { type: "string" }, message: { type: "string" } }, required: ["sessionID", "decisionId", "message"], additionalProperties: false },
    },
  },
} as const

export type CriterionView = {
  id: string
  statement: string
  essential: boolean
  invariant: boolean
  kind: string
  status: CriterionStatus
  by?: string
  detail?: string
  at?: number
}

export type TimelineEntry = { t: number; kind: string; text: string }

/** T187: the store the SERVER resolved for this project, project-relative
 *  POSIX. The TUI prints these paths; it never derives one of its own. */
export type StorePaths = { goalsRel: string; archiveRel: string }

export type GoalView = {
  slug: string
  title: string
  outcome: string
  status: string
  reason?: string
  runId: string
  /** Actual run identity for correlating admission attempts, not version labels. */
  sessionID?: string
  lock?: string
  /** T106: the tuple goal_manage accepts, so a caller never loses a round to
   * discovery after a generation change — key, runId, sessionID and lock. */
  target?: GoalTarget
  /** v0.9.5: the harness that produced this run (absent on older runs). */
  harness?: HarnessIdentity
  turn: number
  timeline: TimelineEntry[]
  activeMs: number
  activeSince: number | null
  usage: { tokens: number; cost: number }
  budget: Array<{ name: string; used: number; limit: number }>
  budgetRatio: number
  criteria: CriterionView[]
  steps: Array<{ id: string; title: string; status: string }>
  /** T169: declared workstreams and the host's verdict on each return. */
  workstreams?: Array<{ id: string; title: string; task: string; worker: string; done_when: string; status: string; reason?: string; at?: number }>
  workstreamsProven?: { total: number; accepted: number; rejected: number; pending: number; proven: boolean }
  progress?: { note: string; next?: string; at: number; turn: number }
  verdict?: { passed: boolean; lines: string[]; at: number; turn: number }
  blocker?: { key: string; count: number; reason: string; needs?: string }
  wait?: { until: number; reason: string }
  awaitingUser: boolean
  /** T052: persistent owner-action-required state — stays until the status resolves. */
  actionRequired?: string
  /** T053: what the engine is doing now — the live activity tracer's feed. */
  activity?: { kind: "turn" | "verifying" | "verifier-child" | "cooldown" | "waiting"; since: number; until?: number; detail?: string }
  amendments: number
  flags: number
  updatedAt: number
  /** T187: the resolved store, so every surface names the real folder. */
  store?: StorePaths
}

export type GoalSummary = {
  slug: string
  title: string
  status: string
  priority?: "low" | "medium" | "high"
  sessionID?: string
  proven: number
  total: number
  terminal?: boolean
  attachable?: boolean
  /** Distinguishes live and archived generations even if their slugs match. */
  key?: string
  archived?: boolean
  valid?: boolean
  runId?: string
  lock?: string
  updatedAt?: number
  /** The locked contract's owner intent, for duplicate/overlap triage. */
  intent?: string
  outcome?: string
  progress?: RunProgress
  turn?: number
  steps?: Array<{ id: string; title: string; status: string }>
  /** Raw existing contract metadata: never inferred from CLEO task IDs. */
  meta?: Record<string, unknown>
  supersedes?: string
  configuredAgent?: string
  agent?: string
  sessionTitle?: string
  sessionState?: "present" | "elsewhere" | "missing" | "unknown" | "unassigned"
  issues?: string[]
  details?: { criteria: CriterionView[]; constraints: string[]; nonGoals: string[] }
  handoff?: Handoff
  /** Latest exact launch review/admission receipt, distinct from run status. */
  launch?: LaunchView
}
export type GoalTarget = { key: string; lock: string; runId?: string; sessionID?: string }
export type ManageAction = "pause" | "resume" | "verify" | "attach" | "abort" | "archive" | "rebase"
type RunProgress = { note: string; next?: string; at: number; turn: number }
