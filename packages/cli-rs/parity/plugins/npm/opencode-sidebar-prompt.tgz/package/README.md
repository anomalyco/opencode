# OpenCode Sidebar Prompt

See your last submitted prompt in the OpenCode V2 terminal sidebar, and open its full text whenever you need it.

[npm](https://www.npmjs.com/package/opencode-sidebar-prompt) · [Source](https://gitlab.com/dexterux86/opencode-sidebar-prompt)

```text
Last prompt
Add a section showing the
tokens used in the session…
Open full prompt · /lastprompt
```

## Installation

Requires **OpenCode V2**. This plugin works in the terminal interface only.

```sh
opencode plugin add opencode-sidebar-prompt
```

No cloning or build step is needed. Open a session in a terminal wide enough to show the sidebar.

## Usage

- The sidebar shows the latest submitted prompt for the current session, including queued prompts marked **Queued**. Unsent drafts are not shown.
- Click **Open full prompt**, run `/lastprompt`, or select **Show full last prompt** from `Ctrl+P` to read the complete text. The command also works with the sidebar hidden.
- Scroll with the mouse, arrow keys, or PgUp/PgDown. Press Esc to close.
- Attachment-only prompts are marked as such; file and image contents are not displayed.

The plugin adds to the existing sidebar and does not require `opencode-sidebar-tokens`.

## Options

To change the preview length, edit the plugin's existing entry in `~/.config/opencode/cli.json` (or `$XDG_CONFIG_HOME/opencode/cli.json`), not `opencode.json`. Keep your other plugins and settings.

```json
{
  "$schema": "https://opencode.ai/v2/cli.json",
  "plugins": [
    {
      "package": "opencode-sidebar-prompt",
      "options": {
        "previewLength": 180
      }
    }
  ]
}
```

`previewLength` limits the preview to **40–600 characters**, including the ellipsis. The default is **180**.

No keyboard shortcut is assigned by default. To add one, include this in `cli.json`:

```json
{
  "keybinds": {
    "sidebar.prompt.open": "ctrl+alt+shift+l"
  }
}
```

Configuration changes apply automatically; use `/reload` if needed.

## Privacy and troubleshooting

The plugin does not store additional copies of prompts, collect telemetry, or contact external services. Prompts are visible in the sidebar, so take care when sharing your screen.

If loading fails, click **Click to reload** in the sidebar or run `/lastprompt` again.

## Update or remove

```sh
opencode plugin update opencode-sidebar-prompt
opencode plugin remove opencode-sidebar-prompt
```

If you installed a pinned version, use the same `name@version` reference to remove it. Pinned versions are not updated automatically.

## License

[BSD Zero Clause (0BSD)](LICENSE). Copyright (c) 2026 Marco Casazza.
