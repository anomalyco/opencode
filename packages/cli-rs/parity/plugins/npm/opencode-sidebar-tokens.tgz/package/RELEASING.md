# Publishing to npm

1. Bump the version using the appropriate release type:

   ```sh
   npm version patch
   # Or: npm version minor / npm version major
   ```

2. Push the branch and tags to GitLab:

   ```sh
   git push --tags origin main
   ```
