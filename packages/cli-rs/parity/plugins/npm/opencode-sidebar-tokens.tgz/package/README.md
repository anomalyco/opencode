# OpenCode Sidebar Tokens

See token usage for your current session in the OpenCode V2 terminal sidebar.

[npm](https://www.npmjs.com/package/opencode-sidebar-tokens) · [Source](https://gitlab.com/dexterux86/opencode-sidebar-tokens)

```text
Session tokens
Input                 12,345
Output                   678
Cache read            98,765
Cache write            4,321
Reasoning                 90
```

## Installation

Requires **OpenCode V2**. This plugin works in the terminal interface only.

```sh
opencode plugin add opencode-sidebar-tokens
```

No cloning or build step is needed. Open a session in a terminal wide enough to show the sidebar. If it is hidden, use OpenCode's sidebar toggle command.

The plugin adds to the existing sidebar and does not require `opencode-sidebar-prompt`.

## Understanding the counters

- **Input / Output:** token usage reported by OpenCode for the current provider.
- **Cache read / Cache write:** provider cache usage, not local file activity.
- **Reasoning:** reasoning tokens, shown only when greater than zero.

Counters cover the current session, not your entire account or automatically all subagent sessions. They may update at the end of a step or response rather than continuously.

`—` means data is not available yet. `0` is the value reported by OpenCode; some providers may not report every counter. No combined total is shown because categories can overlap depending on the provider.

If synchronization fails, existing values stay visible. Click the retry message to refresh them.

## Options

To customize the plugin, edit its existing entry in `~/.config/opencode/cli.json` (or `$XDG_CONFIG_HOME/opencode/cli.json`), not `opencode.json`. Keep your other plugins and settings.

```json
{
  "$schema": "https://opencode.ai/v2/cli.json",
  "plugins": [
    {
      "package": "opencode-sidebar-tokens",
      "options": {
        "locale": "en-US",
        "showReasoning": true
      }
    }
  ]
}
```

| Option | Default | Description |
| --- | --- | --- |
| `locale` | `en-US` | Number formatting, such as `12,345`. Use `it-IT` for `12.345`. Invalid locale strings fall back to `en-US`. |
| `showReasoning` | `true` | Set to `false` to hide the Reasoning row. |

Labels are always in English. Configuration changes apply automatically; use `/reload` if needed.

## Update or remove

```sh
opencode plugin update opencode-sidebar-tokens
opencode plugin remove opencode-sidebar-tokens
```

If you installed a pinned version, use the same `name@version` reference to remove it. Pinned versions are not updated automatically.

## License

[BSD Zero Clause (0BSD)](LICENSE). Copyright (c) 2026 Marco Casazza.
